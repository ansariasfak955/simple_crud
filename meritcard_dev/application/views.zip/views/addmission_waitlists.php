 <?php include ('include/header.php'); ?>
 <style type="text/css">
.table > tbody > tr > td, .table > tbody > tr > th {
    padding: 0rem 1rem !important;
}
 </style>
 <div class="content-wrapper">
   <div class="container-full">
     <!-- Content Header (Page header) -->
     <div class="content-header">
       <div class="tabls-title mt-1">
         <a href="<?= base_url('Admissions') ?>" class="">Dashboard</a>
         <a href="<?= base_url('Admissions/admissions_from_requests') ?>" class="">Forms & Requests</a>
         <a href="<?= base_url('Admissions/addmission_waitlists') ?>" class="active">Waitlists</a>
         <a href="<?= base_url('Admissions/programs') ?>" class="">Programs</a>
            
       </div>
       <div class="d-flex align-items-center">
         <div class="w-100s">
           <h4 class="page-title newtittle"> Waitlists</h4>

           <div class="d-inline-block align-items-center">
           </div>
           <div class="haff-widgets">

             <a href="addmission_waitlist_add_student.php" class="btn btn-primary mt-10 waves-effect shadow">+ Add Student</a>
           </div>
         </div>
       </div>
     </div>
     <!-- Main content -->
     <section class="content">
      
       <div class="row">
         <div class="col-12">
           <form>
             <div class="row">
                 <div col = '12' >
           <?php if ($this->session->flashdata('success_msg')) { ?>
                                          
                        <div class="alert alert-success">
                         
                            <strong><?php echo $this->session->flashdata('success_msg'); ?></strong>
                             <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        </div>
                
                <?php } ?>
                
                <?php if ($this->session->flashdata('error_msg')) { ?>
                
                        <div class="alert alert-danger">
                           
                            <strong><?php echo $this->session->flashdata('error_msg'); ?></strong>
                             <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        </div>
                
                <?php } ?>
        </div> 
               <div class="col-lg-12">
                 <div class="card">
                   <div class="card-body">
                     <div class="row align-items-center">
                       

                       <div class="col-lg-6 mb-3 mt-4">
                    <div class="formsetting mb-3">
                      <label class="">Select a waitlist to view</label>
                     <select  class="selectpicker form-control" id="minage" data-container="body" data-live-search="true" title="Select.." data-hide-disabled="false" data-actions-box="true" data-virtual-scroll="false" name="minage">
                        <option>Test</option>
                        <option>Program Name</option>
                      </select>
                    </div>
                   </div>
                   <div class="col-sm-6"></div>
                   <div class="col-sm-3 mb-3">
                     <select class="selectpicker form-control" id="number-multiple" data-container="body" data-live-search="true" title="Search students..." data-hide-disabled="true" data-actions-box="true" data-virtual-scroll="false">
                        <option>Aayush</option>
                        <option>Abhishek</option>
                        <option>Jiyansh</option>
                        <option>Arpit</option>
                        <option>Punit Joshi</option>
                        <option>Pusphak</option>
                        <option>Virendra</option>
                      </select>
                   </div>
                   <div class="col-sm-3 mb-3">
                    <select class="selectpicker form-control" id="number-multiple" data-container="body" data-live-search="true" data-hide-disabled="true" title="Room" data-actions-box="true" data-virtual-scroll="false">
                    <option>Sun Room (A)</option>
                    <option>Sun Room (B)</option>
                    <option>Ck Room (A)</option>
                    <option>Ck Room (B)</option>
                    <option>Dk Room (A)</option>
                    <option>DK Room (B)</option>
             </select>
                   </div>

                   <div class="col-sm-2 mb-3">
                    <select class="selectpicker form-control" id="number-multiple" data-container="body" data-live-search="true" title="Sibling" data-hide-disabled="true" data-actions-box="true" data-virtual-scroll="false">
                    <option>Yes</option>
                    <option>No</option>
                    
                     </select>
                   </div> 

                   <div class="col-sm-2 mb-3">
                    <select class="selectpicker form-control" id="number-multiple" data-container="body" data-live-search="true" title="Min Age" data-hide-disabled="true" data-actions-box="true" data-virtual-scroll="false">
                     <option>0 mo</option>
                           <option>3 mo</option>
                           <option>6 mo</option>
                           <option>9 mo</option>
                           <option>12 mo</option>
                           <option>1 year 3 mo</option>
                     </select>
                   </div>  

                 <div class="col-sm-2 mb-3">
                    <select class="selectpicker form-control" id="number-multiple" data-container="body" data-live-search="true" title="Max Age" data-hide-disabled="true" data-actions-box="true" data-virtual-scroll="false">
                    <option>3 mo</option>
                           <option>6 mo</option>
                           <option>9 mo</option>
                           <option>12 mo</option>
                           <option>1 year 3 mo</option>
                           <option>2 year 5 mo</option>
                     </select>
                   </div>
                  
                    <div class="col-lg-12 col-md-4 col-sm-6 text-end">
                         <button type="reset" class="btn btn-lights mt-5 waves-effect  mr--1">Reset</button>
                         <button type="submit" class="btn btn-primary mt-5 waves-effect shadow mr-3">Search</button>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
           </form>
         </div>
       </div>

       <div class="row ">
         <div class="col-12">
           <div class="box">
             <div class="box-body">
               <div class="table-responsive">
                 <table class="table table-hover mb-0 parent_list" id="complex_header">
                   <thead>
                     <tr>
                       <th>Student Name </th>
                       <th>Paperwork Date </th>
                       <th>Desired Start   </th>
                       <th>Age  </th>
                       <th>Sibling Attending </th>
                       <th></th>
                     </tr>
                   </thead>
                   <tbody>
                  <tr>
                    <td>
                      <div class="student_list">
                          <a href="#">
                            <div class="avtar_img">
                             <img src="assets/images/avatar.png">
                            </div>
                            <div class="info_title">
                              <h5>Ajay</h5>
                              <h6 class="mt-1">Demo room 1</h6>
                            </div>
                          </a>
                        </div>
                      </td>
                        <td></td>
                        <td>12/03/2022</td>
                        <td>1 mo - 10 year</td>
                        <td></td>
                        <td><div class="btn-group">
                           <button class="btn btn-dark dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="icon ti-settings"></i>Action</button>
                           <div class="dropdown-menu dropdown-menu-end" style="">
                             <a class="dropdown-item" href="#"><i class="fa fa-pencil"></i> Enroll</a>
                             <a class="dropdown-item sa-warning" href="#"><i class="fa fa-trash-o"></i> Delete</a>
                           </div>
                         </div></td>
                  </tr>
                       <tr>
                    <td>
                      <div class="student_list">
                          <a href="#">
                            <div class="avtar_img">
                             <img src="assets/images/avatar.png">
                            </div>
                            <div class="info_title">
                              <h5>Pushphak</h5>
                              <h6 class="mt-1">Demo room 1</h6>
                            </div>
                          </a>
                        </div>
                      </td>
                        <td></td>
                        <td>12/03/2022</td>
                        <td>1 mo - 10 year</td>
                        <td></td>
                        <td><div class="btn-group">
                           <button class="btn btn-dark dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="icon ti-settings"></i>Action</button>
                           <div class="dropdown-menu dropdown-menu-end" style="">
                             <a class="dropdown-item" href="#"><i class="fa fa-pencil"></i> Enroll</a>
                             <a class="dropdown-item sa-warning" href="#"><i class="fa fa-trash-o"></i> Delete</a>
                           </div>
                         </div></td>
                  </tr>
                      
                   </tbody>
                 </table>
               </div>
             </div>
           </div>
         </div>
       </div>
      </section>
     <!-- /.content -->
   </div>
 </div>
 <!-- Modal -->
 <!-- /.modal -->
 <?php include ('include/footer.php'); ?>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
 <script src="<?= base_url() ?>assets_pages/js/bootstrap-select.js"></script>
 <script src="<?= base_url() ?>assets_pages/vendor_components/datatable/datatables.min.js"></script>
 <script src="<?= base_url() ?>assets_pages/src/js/pages/data-table.js"></script>
 <script src="<?= base_url() ?>assets_pages/vendor_components/bootstrap-daterangepicker/daterangepicker.js"></script>
 <script src="<?= base_url() ?>assets_pages/vendor_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

 <script type="text/javascript">
   //Date picker
   $('#datepicker').datepicker({
     autoclose: true
   });
   //Date picker
   $('#todatepicker').datepicker({
     autoclose: true
   });

    function toggle(source) {
      checkboxes = document.getElementsByName('checkboxx');
      for(var i=0, n=checkboxes.length;i<n;i++) {
        checkboxes[i].checked = source.checked;
      }
    }
 </script>

<script>
       $('.addmission').addClass('active');
</script>
