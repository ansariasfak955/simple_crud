 <?php include ('include/header.php'); ?>
 <style type="text/css">
   .student_list .dataTables_info,
   .dataTables_length,
   .dt-buttons {
     display: block !important;
   }
  .table
  {
    text-align: center;
  }
  .parent_list>thead>tr>th {
     font-weight: 500;
     background-color: #f3f6f9 !important;
     color: #605c6c;
     font-size: 13px;
     padding: 10px !important;
   }

 .parent_list label
 {
    margin-bottom: -10px;
 }
 </style>
 <link rel="stylesheet" type="text/css" href="assets/vendor_components/date-paginator/bootstrap-datepaginator.min.css">
 <link rel="stylesheet" type="text/css" href="assets/vendor_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
 <link rel="stylesheet" type="text/css" href="assets/vendor_components/bootstrap-daterangepicker/daterangepicker.css">
 <div class="content-wrapper">
   <div class="container-full">
     <!-- Content Header (Page header) -->
     <div class="content-header">
       <div class="tabls-title mt-1">
          <a href="<?= base_url('Admissions') ?>" class="active">Dashboard</a>
         <a href="<?= base_url('Admissions/admissions_from_requests') ?>" class="">Forms & Requests</a>
         <a href="<?= base_url('Admissions/addmission_waitlists') ?>" class="">Waitlists</a>
         <a href="<?= base_url('Admissions/programs') ?>" class="">Programs</a>
        
       </div>
       <div class="d-flex align-items-center">
         <div class="w-100s">
           <h4 class="page-title newtittle">Admissions Dashboard</h4>

           <div class="d-inline-block align-items-center">
           </div>
           <div class="haff-widgets">

             <a href="<?= base_url('Admissions/addmission_add_student') ?>" class="btn btn-primary mt-10 waves-effect shadow">+ New Student</a>
           </div>
         </div>
       </div>
     </div>
     <!-- Main content -->
     <section class="content">

   <div class="dashboard_box">

    <div class="box">
      <div class="row g-0 py-2">
          <div col = '12' >
           <?php if ($this->session->flashdata('success_msg')) { ?>
                                          
                        <div class="alert alert-success">
                         
                            <strong><?php echo $this->session->flashdata('success_msg'); ?></strong>
                             <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        </div>
                
                <?php } ?>
                
                <?php if ($this->session->flashdata('error_msg')) { ?>
                
                        <div class="alert alert-danger">
                           
                            <strong><?php echo $this->session->flashdata('error_msg'); ?></strong>
                             <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        </div>
                
                <?php } ?>
        </div> 

          <div class="col-12 col-xl-3">
            <div class="box-body be-1 border-light">
            <div class="flexbox mb-1">
              <span>
                <span class="icon-User fs-40"><span class="path1"></span><span class="path2"></span></span><br>
                Total Students
 
              </span>  
              <span class="text-primary fs-40"><?= (isset($total_students)) ? $total_students : '0' ?></span>
            </div>
            <div class="progress progress-xxs mt-10 mb-0">
              <div class="progress-bar" role="progressbar" style="width: 35%; height: 4px;" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            </div>
          </div>


          <div class="col-12 col-xl-3 hidden-down">
            <div class="box-body be-1 border-light">
            <div class="flexbox mb-1">
              <span>
                <span class="icon-Selected-file fs-40"><span class="path1"></span><span class="path2"></span></span><br>
              Prospects
              </span>
              <span class="text-info fs-40"><?= (isset($temp_count['Prospects'])) ? $temp_count['Prospects'] : '0' ?> </span>
            </div>
            <div class="progress progress-xxs mt-10 mb-0">
              <div class="progress-bar bg-info" role="progressbar" style="width: 55%; height: 4px;" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            </div>
          </div>


          <div class="col-12 col-xl-3 d-none d-lg-block">
            <div class="box-body be-1 border-light">
            <div class="flexbox mb-1">
              <span>
                <span class="icon-Info-circle fs-40"><span class=""><i class="fad fa-plane-departure"></i></span><span class="path2"></span><span class="path3"></span></span><br>
                 Toured
              </span>
              <span class="text-warning fs-40"><?= (isset($temp_count['Toured']))? $temp_count['Toured'] : '0' ?> </span>
            </div>
            <div class="progress progress-xxs mt-10 mb-0">
              <div class="progress-bar bg-warning" role="progressbar" style="width: 65%; height: 4px;" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            </div>
          </div>


          <div class="col-12 col-xl-3 d-none d-lg-block">
            <div class="box-body be-1 border-light">
            <div class="flexbox mb-1">
              <span>
                <span class="icon-Group-folders fs-40"><span class="path1"></span><span class="path2"></span></span><br>
             Applied
              </span>
              <span class="text-success fs-40"><?= (isset($temp_count['Applied'])) ? $temp_count['Applied'] : '0' ?></span>
            </div>
            <div class="progress progress-xxs mt-10 mb-0">
              <div class="progress-bar bg-success" role="progressbar" style="width: 40%; height: 4px;" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            </div>
          </div>  

          <div class="col-12 col-xl-3 d-none d-lg-block">
            <div class="box-body">    
            <div class="flexbox mb-1">
              <span>
                <span class="icon-Group-folders fs-40"><span class="path1"></span><span class="path2"></span></span><br>
             Waitlist
              </span>
              <span class="text-danger fs-40"><?= (isset($temp_count['Waitlist'])) ? $temp_count['Waitlist'] : '0' ?></span>
            </div>
            <div class="progress progress-xxs mt-10 mb-0">
              <div class="progress-bar bg-danger" role="progressbar" style="width: 40%; height: 4px;" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            </div>
          </div>
        </div>
   </div>


       </div>
       <div class="row">
         <div class="col-12">
           <form>
             <div class="row">
               <div class="col-lg-12">
                 <div class="card">
                   <div class="card-body">
                     <div class="row">
                       <div class="col-lg-3 col-md-4 col-sm-6 mb-3">
                         <select class="selectpicker form-control" id="number-multiple" data-container="body" data-live-search="true" title="Search students..." data-hide-disabled="true" data-actions-box="true" data-virtual-scroll="false">
                           <option>Aayush</option>
                           <option>Abhishek</option>
                           <option>Jiyansh</option>
                         </select>
                       </div>
                       <div class="col-lg-3 col-md-4 col-sm-6 mb-3">
                         <select class="selectpicker form-control" id="number-multiple" data-container="body" data-live-search="true" title="Program" data-hide-disabled="true" data-actions-box="true" data-virtual-scroll="false">
                           <option>Test</option>
                         </select>
                       </div>


                       <div class="col-lg-6 col-md-4 col-sm-6 mb-3">
                         <select multiple="" class="selectpicker form-control" id="number-multiple" data-container="body" data-live-search="true" title="Student Status " data-hide-disabled="true" data-actions-box="true" data-virtual-scroll="false">
                           <option>Prospects</option>
                           <option>Toured</option>
                           <option>Applied</option>
                           <option>Waitlist</option>
                         </select>
                       </div>

                       <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                         <div class="form-group">
                           <div class="input-group input--style">
                             <div class="input-group-addon">
                               <i class="fad fa-calendar-alt"></i>
                             </div>
                             <input type="text" class="form-control pull-right" id="datepicker" placeholder="From Desired Start Date" autocomplete="off">
                           </div>
                         </div>
                       </div>

                       <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                         <div class="form-group">
                           <div class="input-group input--style">
                             <div class="input-group-addon">
                               <i class="fad fa-calendar-alt"></i>
                             </div>
                             <input type="text" class="form-control pull-right" id="todatepicker" placeholder="To Desired Start Date" autocomplete="off">
                           </div>
                         </div>
                       </div>

                       <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                         <select class="selectpicker form-control" id="number-multiple" data-container="body" data-live-search="true" title="Min Age" data-hide-disabled="true" data-actions-box="true" data-virtual-scroll="false">
                           <option>0 mo</option>
                           <option>3 mo</option>
                           <option>6 mo</option>
                           <option>9 mo</option>
                           <option>12 mo</option>
                           <option>1 year 3 mo</option>

                         </select>
                       </div>

                       <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                         <select class="selectpicker form-control" id="number-multiple" data-container="body" data-live-search="true" title="Max Age " data-hide-disabled="true" data-actions-box="true" data-virtual-scroll="false">
                           <option>3 mo</option>
                           <option>6 mo</option>
                           <option>9 mo</option>
                           <option>12 mo</option>
                           <option>1 year 3 mo</option>
                           <option>2 year 5 mo</option>
                         </select>
                       </div>


                       <div class="col-lg-12 col-md-4 col-sm-6 text-end">
                         <button type="reset" class="btn btn-lights mt-5 waves-effect  mr--1">Reset</button>
                         <button type="submit" class="btn btn-primary mt-5 waves-effect shadow mr-3">Search</button>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
           </form>
         </div>
       </div>



      <div class="myadmin-alert alertchat myadmin-alert-img alert-info myadmin-alert-bottom alertbottom2"> 
             <!-- <a href="#" class="closed">&times;</a> -->
             <div class="d-flex">
             <h1><i class="fad fa-users-medical"></i> &nbsp;Selected all students</h1>
             <h5><a href="message_new.php" class="btn btn btn-primary mt-10 waves-effect shadow">Message Selected Families</a></h5>
             </div>
          </div>

      <div class="row addmisstyion_list">
         <div class="col-12">
           <div class="box">
             <div class="box-body">
               <div class="table-responsive">
                 <table class="table table-hover mb-0 parent_list" id="complex_header">
                   <thead>
                     <tr>
                      <th class="w20a">
                        <input type="checkbox" id="md_checkbox_24" class="filled-in chk-col-info showbottom2" onClick="toggle(this)" >
                        <label for="md_checkbox_24" class=""></label>
                      </th>
                       <th>Student Name</th>
                       <th>Age</th>
                       <th>Program(s) </th>
                       <th>Min/Max Age </th>
                       <th>Paperwork Date</th>
                       <th>Desired Start</th>
                       <th>Sibling Attending</th>
                       <th>Pending Forms</th>
                       <th>School Status </th>
                     </tr>
                   </thead>

                   <tbody>
                     <?php if(isset($list) && $list > 0){
                        foreach($list as $val){?>       
                                 <tr>
                      <td class="w20a">
                        <input type="checkbox" id="md_checkbox_21" class="filled-in chk-col-info" name="checkboxx">
                        <label for="md_checkbox_21"></label>
                      </td>
                       <td>
                         <div class="student_list">
                           <a href="#">
                             <div class="avtar_img">
                               <img src="assets/images/avatar.png">
                             </div>
                             <div class="info_title">
                               <h5><?= $val->student_name ?></h5>
                             </div>
                           </a>
                         </div>
                       </td>
                       <td><?= $val->age ?> year</td>                     
                       <td><?= $val->class_name ?></td>
                       <td><?= ($val->max_age == 0)? $val->min_age.' Year/': $val->min_age.' Year/ '. $val->max_age.' Year' ?> </td>
                       <td><?= date('d-m-Y',strtotime($val->date) ) ?></td>
                       <td></td>
                       <td></td>
                       <td></td>
                       <td>
                        <div class="d-flex align-items-center justify-content-end">
                         <div class="select_drop">
                           <select class="selectpicker form-control" onchange="school_status_fun(this.value , <?= $val->temp_s_id ?>)"> >
                             <option <?= ($val->school_status == 'Prospects')?  'selected': '' ?> >Prospects</option>
                             <option <?= ($val->school_status == 'Toured')?  'selected': '' ?>>Toured</option>
                             <option <?= ($val->school_status == 'Applied')?  'selected': '' ?> >Applied</option>
                             <option <?= ($val->school_status == 'Waitlist')?  'selected': '' ?> >Waitlist</option>
                           </select>
                         </div>
                           <a href="#message_new.php" class="chatuser btn btn-light" data-bs-toggle="tooltip" data-bs-original-title="Send Message"><i class="icon-Chat2"></i></a>
                           </div>
                       </td>
                     </tr>

                         <?php }} ?>
                   </tbody>
                 </table>
               </div>
             </div>
           </div>
         </div>
       </div>
      </section>
     <!-- /.content -->
   </div>
 </div>
 <!-- Modal -->
 <!-- /.modal -->
 <?php include ('include/footer.php'); ?>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
 <script src="<?= base_url() ?>assets_pages/js/bootstrap-select.js"></script>
 <script src="<?= base_url() ?>assets_pages/vendor_components/datatable/datatables.min.js"></script>
 <script src="<?= base_url() ?>assets_pages/src/js/pages/data-table.js"></script>
 <script src="<?= base_url() ?>assets_pages/vendor_components/bootstrap-daterangepicker/daterangepicker.js"></script>
 <script src="<?= base_url() ?>assets_pages/vendor_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
 <script src="<?= base_url() ?>assets_pages/src/js/pages/notification.js"></script>
 <script type="text/javascript">
   //Date picker
   $('#datepicker').datepicker({
     autoclose: true
   });
   //Date picker
   $('#todatepicker').datepicker({
     autoclose: true
   });

    function toggle(source) {
      checkboxes = document.getElementsByName('checkboxx');
      for(var i=0, n=checkboxes.length;i<n;i++) {
        checkboxes[i].checked = source.checked;
      }
    }
 </script>
 <script>
 
        function school_status_fun(s_status,id){
              $.ajax({
        type: 'post',
        url: "<?= base_url('Admissions/update_school_status') ?>",
        data: {id:id,s_status:s_status},
        async: false,
                                                                                                                      
        success: function(data){
          var res = $.parseJSON(data);
          if (res.status){
              window.location.reload(); 
            }
            
        }
        });
        
        }
 
  $('.addmission').addClass('active');
</script>
